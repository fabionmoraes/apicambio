<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Moeda;

class HomeController extends Controller
{
    public function index()
    {
        $dados = Moeda::get();

        return response()->json($dados);
    }
}
